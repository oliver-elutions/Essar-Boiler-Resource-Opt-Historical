import json
import os.path as osp
import pandas as pd
import pickle
import logging

def read_json(opt_path):
    """
    Function to load a json file as a dictionary

    Parameters
    ----------
    args: List[str]
        input path to the json file to be read, separate arguments will be combined in to a single path: ie foo, bar, test.json -> foo/bar/test.json    

    Returns
    -------
    data: Dict[str, ?]
        json file as a dictionary
    """
    path = osp.join(opt_path)
    with open(path, 'r') as f:
        data = json.load(f)
    return data

def write_json(data: dict, *args, indent:int = 4, **kwargs) -> None:
    """
    Function to write a dictionary out to a json file --- according to the json standards, the dictionary keys must be strings
    Parameters 
    ----------
    data : dict
        dictionary to be written to a json file
    args : str
        path for the file to be written to
    kwargs : dict
        additional keyword arguments to json.dump
    """

    out_path = osp.join(*args)

    with open(out_path, 'w') as fp:
        json.dump(data, fp, indent=indent, **kwargs)

    return

def read_pickle(*args:str):
    """
    Function to read pickle files

    Parameters
    ----------
    args: List[str] | str
        input path to the pickle file to be read, separate arguments will be combined in to a single path: ie foo, bar, test.json -> foo/bar/test.pkl   

    Returns
    -------
    data : ?
        contents of the pickle file    
    """
    file_path = osp.join(*args)

    with open(file_path, 'rb') as fp:
        data = pickle.load(fp)

    return data

def write_pickle(model, *args:str):
    """
    Function to write out pickle files

    Parameters
    ----------
    model: 
        model to be saved
    args: List[str] | str
        output path to the json file to be read, separate arguments will be combined in to a single path: ie foo, bar, test.json -> foo/bar/test.pkl     
    """

    out_path = osp.join(*args)

    with open(out_path, 'wb') as f:
        pickle.dump(model, f)

    return

def setup_main_logger(logger_file_name:str):
    """
    Function to setup main logger in script. This logger will be called with 'logging.info'.

    Parameters
    ----------
    logger_file_name: str 
        name of logger file to be saved    
    """

    formatstr = '%(asctime)s: %(levelname)s: %(funcName)s Line: %(lineno)d %(message)s'
    datestr = '%m/%d/%Y %H:%M:%S'
    logging.basicConfig(
        level=logging.INFO, 
        format=formatstr, 
        datefmt=datestr, 
        handlers=[
            logging.FileHandler(f'{logger_file_name}.log'),
            logging.StreamHandler()
            ]
        )

    return

def setup_backup_logger(logger_file_name:str, logging_script_name:str):
    """
    Function to setup backup logger in script. This logger will be called with '{logging_script_name}.info'.

    Parameters
    ----------
    logger_file_name: str 
        name of logger file to be saved    
    logger_script_name: str 
        name of logger in the script    
    """

    formatstr = '%(asctime)s: %(levelname)s: %(funcName)s Line: %(lineno)d %(message)s'
    datestr = '%m/%d/%Y %H:%M:%S'
    handler = logging.FileHandler(f'{logger_file_name}.log')
    handler.setFormatter(logging.Formatter(fmt=formatstr, datefmt=datestr))

    backup_logger = logging.getLogger(f"{logging_script_name}")
    backup_logger.setLevel(logging.WARNING)
    backup_logger.addHandler(handler)
    
    return backup_logger

