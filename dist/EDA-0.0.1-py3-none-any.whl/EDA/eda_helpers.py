import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import missingno as msno

def data_overview(df):
    """
    Function to examine dataset - gives summary stats
    Parameters
    ----------
    df : DataFrame
        dataframe to examine
    """
    df_ov = pd.DataFrame(index=df.columns)
    total = df.shape[0]
    df_ov['dtype'] = df.dtypes
    df_ov['total_df_obs'] = df.shape[0]
    df_ov['present_obs'] = df.count()
    df_ov['null_count'] = df_ov['total_df_obs'] - df.count()
    df_ov['null_percent'] = round(df_ov['null_count']/total * 100, 2)
    df_ov['zero_count'] = df[df == 0].count()
    df_ov['zero_perc(%)'] = round(df_ov['zero_count']/total * 100, 2)
    df_ov['unique_count'] = df.nunique()
    df_ov['unique_perc(%)'] = round(df_ov['unique_count']/total * 100, 2)
    
    return df_ov


def plot_tags(df):
    """
    Function to plot tags in dataframe
    Parameters
    ----------
    df : DataFrame
        dataframe to examine
    """
    sns.set(rc={'figure.figsize':(15.7,5)})

    numerical_cols = df.select_dtypes(include=[np.number])
    factor_cols = df.select_dtypes(exclude=[np.number])

    for col in numerical_cols:
        plt.plot(df[col], label = f'{col}');
        plt.title(f'{col} initial');
        plt.legend();
        plt.show();

    for col in factor_cols:
        counts = df[col].value_counts()
        counts.plot.bar();
        plt.show();

    return


def plot_missing_per_obs(df):
    """
    Function to show number of missing observations per timestamp
    Parameters
    ----------
    df : DataFrame
        dataframe to examine
    """
    sns.set(rc={'figure.figsize':(15.7,5)})
    miss_vals = df.isna().sum(axis = 1)
    plt.plot(miss_vals);
    plt.title("Missing Tags per Observation");
    plt.show();

    msno.matrix(df)

    return


def plot_corr(df):
    """
    Function to plot correlation matrix of dataframe
    Parameters
    ----------
    df : DataFrame
        dataframe to examine
    """
    corr_df = df.corr()
    mask = np.triu(corr_df)
    sns.heatmap(corr_df, mask = mask, annot = True, cmap = 'RdBu')

    return


def calc_missing_present_obs(df, missing_tags, output_path):

    # number of obs per tag
    count_df = pd.DataFrame()   

    for tag in df.columns:
        number_present = df.loc[:, tag].count()
        number_missing = df.loc[:, tag].isna().sum()
        
        current_df = pd.DataFrame({f'{tag}': [number_present, number_missing]}, 
                                index = ['Present Observations', 'Missing Observations'])
        count_df = pd.concat([count_df, current_df], axis = 1)  

    # add in counts for missing tags (won't be in dataframe)
    missing_df = pd.DataFrame() 

    for tag in missing_tags:
        miss_df = pd.DataFrame({f'{tag}': [0, df.shape[0]]},
                                index = ['Present Observations', 'Missing Observations'])
        missing_df = pd.concat([missing_df, miss_df], axis = 1)

    # add missing tags
    count_df = pd.concat([count_df, missing_df], axis = 1)

    # save dataframe
    count_df.to_csv(output_path)

    return count_df