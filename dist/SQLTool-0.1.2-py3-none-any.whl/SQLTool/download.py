import logging
import pandas as pd
from tqdm import tqdm
from tqdm.contrib.logging import logging_redirect_tqdm
from typing import Union, List

# local imports
from .data_processing import NoResultsError, format_historically, format_live
from .queries import initial_query, final_query, BadQueryError, MissingDBInfoError


def download_data_for_all_tags(tag_list, client, server, property_value, **kwargs) -> List[pd.DataFrame]:
    """
    Function to download data for all the tags 

    Parameters
    ----------
    tag_list : List[str]
        tag list
    client : str
        client that the data is for
    server : str
        server name
    property_value : int
        property ID value
    kwargs : Dict[str] -> ?
        additional arguments to final_query in this case:
        start_date : str | datetime.datetime
            starting date
        end_date : str | datetime.datetime
            ending date
        rate : int
            resampling rate
        unit : str
            timescale for resampling  
    
    Returns
    -------
    all_data : List[pd.DataFrame]
        all data that was requested
    """
    all_data = [None] * len(tag_list)
    logger = logging.getLogger(__name__)
    
    with logging_redirect_tqdm():
        for i, tag in enumerate(tqdm(tag_list)):
            logger.info(f"\tStarting variable: {tag}")
            try:
                propertyID, database = initial_query(tag, client, server, property_value)

            except BadQueryError as e:
                logger.warning(f"Skipping Tag: {tag} due to bad query")
                logger.error(str(e))

            except MissingDBInfoError:
                logger.warning(f"Skipping Tag: {tag} due to missing database info")
                logger.error(str(e))

            else:
                all_data[i] = final_query(tag, client, server, propertyID, database, **kwargs)
    
    # filter out data that isn't a dataframe (missing)
    # non_missing = [thing for thing in all_data if isinstance(thing, pd.DataFrame)]
    return all_data

# NOTE: this could be a decorator ... that might make it less clear tho ...
def download_and_format(tag_list: List[str], client: str, server: str, property_value : int, live:bool = False, **download_config) -> Union[List[pd.DataFrame], pd.DataFrame]:
    """
    High level function to download data for the tags provided then format and save the results

    Parameters
    ----------
    tag_list : List[str]
        tags to download from the server (must be the full object/datapoint names)
    client : str
        name of the client (usually suffixed with a training underscore ie Solenis_)
    server : str
        name of the server where the data is
    propert_value : int
        property ID value
    live : bool, default = False
        whether to format the data historically (false) or in the live format (true)
    download_config : Dict[str, Any]
        parameters to control the download process

    Returns
    -------
    final_data : Union[List[pd.DataFrame], pd.DataFrame]
        the final data, pd.DataFrame if live=False, and list[pd.DataFrame] if live=True
    missing_data : Optional[List[str]]
        tags that failed to download, only returned in live=False
    """
    # download the data
    logger = logging.getLogger(__name__)
    logger.info("Downloading Tags")
    all_data = download_data_for_all_tags(tag_list, client, server, property_value, **download_config)

    if live:
        try:
            final_data = format_live(*all_data)
            return final_data
        except NoResultsError as e:
            logger.error(str(e))
            raise e
    else:
        try:
            final_data = format_historically(*all_data)
        except NoResultsError as e:
            logger.error(str(e))
            raise e

        # TODO: find a way to vall this validate procedure after the live data formatting as well ... also wrap this into a function?
        logger.info(f"Number of requested tags: {len(tag_list)}")
        logger.info(f"Number of tags grabbed {final_data.shape[1]}")
        final_tags = final_data.columns.tolist()

        # TODO: Write out missing tags to a file
        missing_tags = []

        if len(final_tags) < len(tag_list):
            missing_tags = [tag for tag in tag_list if tag not in final_tags]
            logger.info(f"Missing tags are: {', '.join(missing_tags)}")

        return final_data, missing_tags