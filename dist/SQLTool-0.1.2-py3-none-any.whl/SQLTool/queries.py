import logging
import pandas as pd
import pyodbc

from .utils import read_json, load_conversions


class BadQueryError(Exception):
    def __init__(self, tag, client, server):
        self.tag = tag
        self.client = client
        self.server = server

    def __str__(self):
        return f"BadQueryError: No result found for this query --- Tag: {self.tag}, Client: {self.client}, Server: {self.server}"

class MissingDBInfoError(Exception):
    def __init__(self, tag, client, server, property_id, database):
        self.tag = tag
        self.client = client
        self.server = server
        self.property_id = property_id
        self.database = database

    def __str__(self):
        return f"""MissingDBError: Query returned Missing Database Info:\nQuery Parameters: Tag: {self.tag}, Client: {self.client}, Server: {self.server}\n
        Query Result: Property Id: {self.property_id}, Database: {self.database}"""


class RateError(Exception):

    def __init__(self, rate, max_threshold, min_threshold):
        self.rate = rate
        self.max_threshold = max_threshold
        self.min_threshold = min_threshold

    def __str__(self):
        return f"RateError: Max rate is {self.max_threshold} seconds (4 hours) and min rate is {self.min_threshold}, given rate was {self.rate} seconds. Please set rate within range."
    

class RateTypeError(Exception):
    
    def __init__(self, rate):
        self.rate = rate
    
    def __str__(self):
        return f"RateTypeError: Inputted rate is not an integer. Please input rate as an integer."

def check_rate(rate: int, max_threshold: int = 14400, min_threshold = 0) -> None:
    """
    Function that checks inputted rate

    Parameters
    ----------
    rate : int
        resampling rate
    max_threshold : int , default = 14400
        max resampling rate, 14400 seconds (4 hours)
    min_threshold : int, default = 0
        min resampling rate, 0 seconds
    """
    if rate > max_threshold:
        raise RateError(rate, max_threshold, min_threshold)
    elif rate < min_threshold:
        raise RateError(rate, max_threshold, min_threshold)
    elif not isinstance(rate, int):
        raise RateTypeError(rate)
    return


def initial_query(tag, client, server, property_value):
    """
    Initial query to get the propertyID and the Database name for the tag

    Parameters
    ----------
    tag : str
        object name of the tag
    client : str
        name of the client
    server : str
        string name of server
    property_value: int
        property ID value

    Returns
    -------
    propertyID : int
        property id for the tag (object name) --- if None then the process did not work
    database : str
        name of the data base where the data is stored --- if None then the process did not work
    """
    # connect to the database and make a cursor
    connection1 = pyodbc.connect(
        'Driver={SQL Server};'
        f'Server={server}.elutions.com;'
        f'Database={client}Sys;'
        'trusted_connection=true'
        )

    # define query and execute it 
    # NOTE: the property id for the live deployment will always be -6 ... it is hardcoded in this script ... this may be a limitation in the future
    query = """SELECT oi.Name [ObjectInstanceName], oi.ID [ObjectInstanceId], aop.ID [ArchivedObjectPropertyId],
        ? + ad.Name [ArchiveDatabaseName], pd.Name [PropertyName], aop1.RecordRate [RecordName], 
        '#' + cast(oi.ID as varchar) + '.' + pd.Name [Datasource] 
        FROM ObjectInstances oi 
        JOIN ArchivedObjectPropertiesID aop 
        ON aop.ObjectInstanceID = oi.ID 
            AND aop.PropertyDefinitionID = ? 
            AND aop.Deleted = 0 
        JOIN ArchivedObjectProperties aop1 
        ON aop1.ID = aop.ID 
        JOIN ArchiveDatabases ad 
        ON ad.ID = aop1.ArchiveDatabaseID 
        JOIN PropertyDefinitions pd 
        ON pd.ID = aop.PropertyDefinitionId 
        WHERE oi.Name = ? and oi.ObjectTypeId = -631 
            AND oi.Deleted = 0;"""
    
    # initialize propertyID and database ...
    propertyID = None
    database = None

    with connection1:
        cursor1=connection1.cursor()
        cursor1.execute(query, (client, property_value, tag))

        # extract propertyID and database
        # this should only return one row in the query 
        # NOTE: should handle if there is no result ...
        result = cursor1.fetchall()
        if not result:
            raise BadQueryError(tag, client, server)
        for row in result:
            # TODO: maybe add some validation here ... there should only be one row of data ...
            propertyID=str(row[2])

            try:
                # This try except block is basically in cases where Database is *client*_MSBData, then it checks both MSBData and _Data database
                database = str(row[3])
                
            except IndexError:
                # NOTE: figure out which exception this should catch here --- IndexError and 
                # This try except block is basically in cases where Database is *client*_MSBData, then it checks both MSBData and _Data database
                database = client+"Data"

    if not propertyID or not database:
        raise MissingDBInfoError(tag, client, server, propertyID, database)
    # NOTE: if propertyID is still None then it is an error code
    return propertyID, database

def final_query(tag, client, server, propertyID, database, start_date, end_date, rate=1, unit='minutes'):
    """
    Final query that recieves all the info to grab the data requested

    Parameters
    ----------
    tag : str
        tag of interst (object name)
    client : str
        client
    server : str
        server where the data is
    propertyID : int
        property Id of the tag
    database : str
        database where the data is stored
    start_date : str | datetime.datetime
        start date 
    end_date : str | datetime.datetime
        end date
    rate : int, default = 1 (1 minute)
        resample rate (in minutes --- converted in this function) NOTE: pass 0 for no resampling ...
    unit : str, default='minutes'
        timescale to resample at. One of (s)econds, (m)inutes, (h)ours

    Returns
    -------
    data : pd.DataFrame
        requested data --- columns are tag, timestamp, value
    """
    # FIXME: find a way to generalize this path
    conversion_map = load_conversions()
    # convert the rate to proper time scale
    try: 
        rate *= conversion_map[unit]
    except KeyError as e:
        msg = f"Unit {unit} is not supported: Supported units are (s)econds, (m)inutes and (h)ours"
        logging.error(msg)
        raise e

    try:
        check_rate(rate)
    except (RateError, RateTypeError) as e:
        logging.error(str(e))
        raise e

    connection = pyodbc.connect(
        driver='{SQL Server}',
        host=server+'.elutions.com',
        database=client+'Sys',
        trusted_connection=True
        )

    query_raw = f""" SELECT ?, da.[TimestampGMT], da.[Value]
        FROM [{database}].[dbo].[DataArchive] da
        WHERE da.[ObjectPropertyId] = ?
            AND da.TimestampGMT >= ?
            AND da.TimestampGMT < ?
        ORDER BY da.[TimestampGMT];    
    """

    """
    Steps for resampling based on the input rate:
    1. convert to date to unix time --- cast and datediff
    2. round unix time off according to the given rate: divide and cast then multiply
    3. convert rounded unix time back to date format
    """
    # NOTE: avoid string injection with f-strings when possible --- need to use it for database since it is inside [] and using it for rate since it is used 4x
    # See string injection concerns here: https://www.hacksplaining.com/prevention/sql-injection
    data_query = f""" SELECT ?, 
        DATEADD(s, CAST(DATEDIFF(s, '1970-01-01 00:00:00.000', da.[TimestampGMT]) / {rate} AS int) * {rate},'1970-01-01 00:00:00')  [aggregate timestamp],
        AVG(da.Value) [avg]      
        FROM [{database}].[dbo].[DataArchive] da 
        WHERE da.[ObjectPropertyID] = ? 
            AND da.[TimestampGMT] >= ? 
            AND da.[TimestampGMT] < ?
        GROUP BY CAST(DATEDIFF(s, '1970-01-01 00:00:00.000', da.[TimestampGMT]) / {rate} AS int) * {rate}
        ORDER BY 2;"""

    with connection: 
        cursor = connection.cursor()

        # TODO: add some error handling here
        # 1. If the query is empty (check if there is anything in data ...)

        # need a different query for raw data :( ... look into improving this ... add _ to avoid naming collision 
        final_query_ = data_query if rate != 0 else query_raw
        cursor.execute(final_query_, (tag, propertyID, start_date, end_date))

        # TODO: add check for data
        data = cursor.fetchall()

        # explicitly convert data to list of tuples ... currently it is of type pyodbc.Row ...
        data = [tuple(row) for row in data]
        # TODO: check if tuple fails
        data = pd.DataFrame(data, columns = ["Tag","TimeStamp","Value"]) 
        data['TimeStamp'] = pd.to_datetime(data['TimeStamp'])

        return data
    