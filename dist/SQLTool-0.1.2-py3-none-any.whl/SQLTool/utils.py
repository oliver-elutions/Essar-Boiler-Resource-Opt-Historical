import json
from functools import wraps
import logging
import os.path as osp
from typing import Tuple
import sys
import importlib_resources

# if sys.version_info < (3, 9):
#     # importlib.resources either doesn't exist or lacks the files()
#     # function, so use the PyPI version:
#     import importlib_resources
# else:
#     # importlib.resources has files(), so use that:
#     import importlib.resources as importlib_resources

def read_json(*args):
    """
    Function to load a json file as a dictionary

    Parameters
    ----------
    args: List[str]
        input path to the json file to be read, separate arguments will be combined in to a single path: ie foo, bar, test.json -> foo/bar/test.json    

    Returns
    -------
    data: Dict[str, ?]
        json file as a dictionary
    """
    path = osp.join(*args)
    with open(path, 'r') as f:
        data = json.load(f)
    return data


def log_before(msg):
    """Decorator to log a message before the function executes"""

    def outer_func(func):
        """outer function"""
        
        @wraps(func)
        def wrapper(*args, **kwargs):
            """wrapper function"""
            logging.info(msg)
            result = func(*args, **kwargs)

            return result

        return wrapper

    return outer_func


def check_client_name(func):
    """Decorator to check the client's name (Should end with an underscore)"""
    @wraps(func)
    def wrapper(client:str) -> Tuple[str, str, str, str]:
        """Function to clean the client's name"""

        if not client.endswith('_'):
            client += '_'
        
        # Force name to match the format of the keys
        client = client[0].upper() + client[1:].lower()

        return func(client)
    return wrapper


def load_client_info() -> dict:
    """
    Load client information
    
    Returns
    -------
    data: Dict[str, ?]
        json file as a dictionary
        
    """
    # load data subdirectory
    pkg = importlib_resources.files("SQLTool.data")
    
    # create path for client info
    client_info_path = pkg/"client_info.json"

    # return client info JSON 
    return read_json(client_info_path)

def load_conversions() -> dict:
    """
    Load conversions
    
     Returns
    -------
    data: Dict[str, ?]
        json file as a dictionary

    """
    # load data subdirectory
    pkg = importlib_resources.files("SQLTool.data")
    
    # create path for conversions
    conversion_path = pkg/"conversion_map.json"

    # return client info JSON 
    return read_json(conversion_path)



@check_client_name
def get_server_info(client: str) -> Tuple[str, str, str, str]:
    """
    Function to get the server info for a client

    Parameters 
    ----------
    client : str
        client name

    Returns
    -------
    server : str
        server name which holds the data
    data_server : str
        additional server name that holds the data
    uid : str
        username for the server
    pwd : str
        password for the server    
    """

    # NOTE: is there any issue with only loading the client info here??? ... Also is there an issue with hardcoding this path?

    client_info = load_client_info()

    try:    
        server, data_server, uid, pwd = client_info[client].values()
    except KeyError as e:
        msg = f"Client {client} is not found: Supported clients are {', '.join(client_info.keys())}"
        logging.error(msg)
        raise e
    else:
        return server, data_server, uid, pwd
