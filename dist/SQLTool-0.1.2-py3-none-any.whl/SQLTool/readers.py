import pandas as pd
from typing import List

from .utils import read_json
FILE_TYPES = ['csv', 'xlsx', 'json', 'txt']

class UnsupportedFileType(Exception):
    pass

# def clean_missing_and_duplicates(func):
#     """Decorator to drop missing and duplicates from a series"""
#     def wrapper(*args, **kwargs) -> List[str]:
#         """
#         Function to drop missing variables and drop duplicates

#         Parameters
#         ----------
#         tag_list : pd.Series
#             tag list
        
#         Returns
#         -------
#         subset : List[str]
#             tag list with duplicates and missing dropped
#         """
#         tag_list = func(*args, **kwargs)
#         return tag_list.dropna().drop_duplicates().tolist()
#     return wrapper

def clean_missing_and_duplicates(tag_list: pd.Series) -> List[str]:
        """
        Function to drop missing variables and drop duplicates

        Parameters
        ----------
        tag_list : pd.Series
            tag list
        
        Returns
        -------
        subset : List[str]
            tag list with duplicates and missing dropped
        """
        return tag_list.dropna().drop_duplicates().tolist()


def read_file(file_path, tag_list_col_name, *args, **kwargs) -> List[str]:
    """
    High level function to read in data from a few different file types

    Parameters
    ----------
    file_path : str
        path to the file to read
    tag_list_col_name : str
        name of the column which holds the tag list
    args : List[?]
        additonal arguments to the read function
    kwargs : Dict[str] -> ?
        additional kwargs to the read function

    Returns : List[str]
        list of tags (object names) --- coerced to a list in the decorator
    """
    extension = file_path.split('.')[-1]
    # check if the extension is supported
    if extension not in FILE_TYPES:
        raise UnsupportedFileType(f"File Type {extension} is not supported. Supported types are: {', '.join(FILE_TYPES)}")

    if extension == 'csv' or extension == 'txt':
        data = pd.read_csv(file_path, *args, **kwargs)[tag_list_col_name]
    elif extension == 'xlsx':
        data = pd.read_excel(file_path, *args, **kwargs)[tag_list_col_name]
    else:
        return read_json(file_path)[tag_list_col_name]
    
    # NOTE: maybe use a decorator to do this ... it would allow people to load up the function separately without the cleaning attached ...
    return clean_missing_and_duplicates(data)
    



    
    
