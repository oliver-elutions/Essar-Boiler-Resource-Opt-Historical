import argparse
import logging
import os
import os.path as osp
import pandas as pd

# local imports
from .download import download_and_format
from .readers import read_file
from .utils import read_json, get_server_info


def parse_args():
    """Function to parse command line arguments"""
    parser = argparse.ArgumentParser()

    parser.add_argument('file_path', type=str, help='File with the tag list')
    parser.add_argument('client', type=str, help='Client to download data for')
    parser.add_argument('config_path', type=str, help='Path to config (must be json)')
    parser.add_argument('--out-path', type=str, required=False, default=os.getcwd(), help='Output directory')
    parser.add_argument('--live', action='store_true', required=False, help='Wether the output should be stored in the live deployment format')
    parser.add_argument('--file-name', type=str, required=False, help='Output file name (with extension)')

    args = parser.parse_args()
    return args


def save_data(df, outpath, filename='data.csv', live=False) -> None:
    """
    Function to save a dataframe to the desired path

    Parameters
    ----------
    df : pd.DataFrame
        data of interest
    outpath : str
        output directory
    filename : str
        name of the output file ... if in live mode this will be a timestamp otherwise it will be a filename

    Returns
    -------
    """
    if live:
        df.to_csv(osp.join(outpath, filename), index=False, header=False, sep=';')
        return 
    
    df.to_csv(osp.join(outpath, filename))
    return


def main():
    """Main Function"""
    # TODO: separate out the parsing and loading of command line arguments and the high level function to run each step
    # This will make it easier to support as a software toolkit

    args = parse_args()

    # set up logger
    formatstr = '%(asctime)s: %(levelname)s: %(funcName)s Line: %(lineno)d %(message)s'
    datestr = '%m/%d/%Y %H:%M:%S'
    logging.basicConfig(
        level=logging.INFO, 
        format=formatstr, 
        datefmt=datestr, 
        handlers=[
            logging.FileHandler('data_download.log'),
            logging.StreamHandler()
            ]
        )

    # read config

    config = read_json(args.config_path)
    data_config = config['data_params']
    download_config = config['download_params']

    logging.info('Reading Server info')
    server, _, uid, pwd = get_server_info(args.client)

    # read in tag list somehow ...
    logging.info(f'Reading input file: {args.file_path}')
    tags_list = read_file(args.file_path, data_config["tag_list_col_name"], *data_config['args'], **data_config['kwargs'])

    final_data, missing_tags = download_and_format(tags_list, args.client, server, args.live, **download_config)

    # determine the output format and ensure the output directory is made
    logging.info("Creating output directory")
    os.makedirs(args.out_path, exist_ok=True)

    logging.info("Saving Downloaded data")
    if args.live:
        for timestamp, df in final_data.items():
            logging.info(f"Saving file: {timestamp}.csv to {args.out_path}")
            save_data(df, args.out_path, f"{timestamp}.csv", args.live)

    else:
        filename = args.file_name if args.file_name else "data.csv"
        logging.info(f"Saving file: {filename} to {args.out_path}")
        save_data(final_data, args.out_path, filename, args.live)

    if missing_tags:
        # NOTE: if any tags were missing save them out to a file ...
        missing_df = pd.DataFrame({'Tag': missing_tags})
        missing_df.to_csv(osp.join(args.out_path, 'missing_tags.csv'))

    return

if __name__ == '__main__':
    main()