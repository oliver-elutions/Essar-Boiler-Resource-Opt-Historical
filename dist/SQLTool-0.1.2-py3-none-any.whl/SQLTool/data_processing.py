import pandas as pd
from .utils import log_before

class NoResultsError(Exception):
    def __str__(self):
        # TODO: add in more info here for the error ...
        return f"NoResultsError: No data found for any tags in the specified date range"

@log_before("Formatting data to historical format")
def format_historically(*data):
    """
    Function to format data in historical format where the index is the timestamp and the columns are each tag

    Parameters
    ----------
    data : List[pd.DataFrame]
        data of interest --- each dataframe is for a separate tag, the columns will be tag, timestamp and value

    Returns 
    -------
    final : pd.DataFrame
        single dataframe with all the tags
    """
    missing = [True if isinstance(thing, list) else False for thing in data]
    if all(missing):
        raise NoResultsError()

    all_data = pd.concat(data, axis=0, join='outer', ignore_index=True)
    all_data = all_data.rename(columns={'Value':'value', 'TimeStamp':'Date', 'Tag':'Name'})

    final = all_data.pivot_table(index='Date', columns='Name', values='value')
    # NOTE: make sure this line below is required
    final.index = pd.to_datetime(final.index)

    return final

@log_before("Formatting data to live format")
def format_live(*data):
    """
    Function to format the downloaded data into the live deployment format

    Parameters
    ----------
    data : List[pd.DataFrame]
        data of interest --- each dataframe is for a separate tag, the columns will be tag, timestamp and value

    Returns
    -------
    live_data : Dict[str] -> pd.DataFrame
        dictionary where the keys are the timestamp and the values are the associated live deployment dataframe ready to be written out

    """
    raise NotImplementedError("This is not implemented yet ... Figuring out Property Information about the datapoints")
    return
        